<?php

/**
 * Defaults Values
 */

return array(
	'gid' => '',
	'height' => 200,
	'per_time' => 3,
	'rows'	=> 1,
	'multiscroll' => 0,
	'center' => 0,
	'nocrop' => 0,
	'random' => 0,
	'watermark' => 0,
	'autoplay' => 'auto',
	'overlay' => 'auto',
	
	'overlay' => 'default',
);