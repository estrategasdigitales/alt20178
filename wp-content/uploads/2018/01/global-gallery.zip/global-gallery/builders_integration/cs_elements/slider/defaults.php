<?php

/**
 * Defaults Values
 */

return array(
	'gid' => '',
	'width' => 100,	'width_unit' => '%',
	'height' => 55, 'height_unit' => '%',
	'random' => 0,
	'watermark' => 0,
	'autoplay' => 'auto',
);