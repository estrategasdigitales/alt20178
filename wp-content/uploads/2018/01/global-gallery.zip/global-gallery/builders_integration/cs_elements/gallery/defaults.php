<?php

/**
 * Defaults Values
 */

return array(
	'gid' => '',
	'random' => 0,
	'watermark' => 0,
	'pagination' => '',
	
	'overlay' => 'default',
);